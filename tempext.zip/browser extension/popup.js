chrome.tabs.onUpdated.addListener(async function (tabId, changeInfo, tab) {
    console.log(tabId, changeInfo, tab)
    if (changeInfo.status == 'complete') {
        await chrome.alarms.create('demo-default-alarm', {
            delayInMinutes: 0.01,
            periodInMinutes: 0.01
        });
    }
  })

  chrome.alarms.onAlarm.addListener((alarm) => {
    console.log('hellloooooooo')
  });